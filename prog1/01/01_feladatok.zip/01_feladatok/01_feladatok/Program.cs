﻿using System;

namespace _01_feladatok
{
    class Program
    {
        static void Main(string[] args)
        {
            // 01a
            //Console.WriteLine("adj meg egy nevet: ");
            //string nev = Console.ReadLine();
            //Console.Write("Szia: ");
            //Console.Write(nev);
            //Console.Write("!");

            //01b
            //Console.Write("adj meg egy nevet: ");
            //string nev = Console.ReadLine();
            //Console.WriteLine("Szia " + nev + "!");


            //02
            //Console.Write("adj meg egy nevet: ");
            //string nev = Console.ReadLine();
            
            //Console.Write("add meg az eletkorod: ");
            //int eletkor = int.Parse(Console.ReadLine());
            //eletkor += 5;
            //// eletkor = eletkor + 5;

            //Console.WriteLine("Szia " + nev + "!" + " Te " + eletkor + " eves vagy!");










            Console.ReadLine();

            
        }
    }
}
