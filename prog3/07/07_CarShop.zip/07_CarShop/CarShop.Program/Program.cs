﻿using CarShop.Data;
using CarShop.Logic;
using CarShop.Repository;
using ConsoleTools;
using System;
using System.Linq;

namespace CarShop.Program
{
    class Program
    {
        static void Main(string[] args)
        {
            CarDbContext ctx = new CarDbContext();
//            Console.WriteLine(ctx.Cars.Count());

            CarRepository carRepository = new CarRepository(ctx);
            CarLogic carLogic = new CarLogic(carRepository);

            ConsoleMenu consoleMenu = new ConsoleMenu();
            consoleMenu.Add("CarC", () => { });
            consoleMenu.Add("CarR", () => { 
                var res =carLogic.GetAll();
                foreach (var item in res)
                {
                    Console.WriteLine(item.Model);
                }
                Console.ReadLine();
            });
            consoleMenu.Add("CarU", () => { });
            consoleMenu.Add("CarD", () => { });
            consoleMenu.Add("CarAverage", () => { 
            
                var res =carLogic.GetBrandAverages();
                foreach (var item in res)
                {
                    Console.WriteLine(item);
                }
                Console.ReadLine();
            });
            consoleMenu.Show();
        }
    }
}
