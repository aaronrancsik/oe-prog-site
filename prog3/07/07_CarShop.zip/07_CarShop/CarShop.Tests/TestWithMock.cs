﻿using CarShop.Logic;
using CarShop.Models;
using CarShop.Repository;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarShop.Tests
{
    class TestWithMock
    {
        Mock<ICarRepository> mockCarRepository = new Mock<ICarRepository>();
        CarLogic carLogic;
        public TestWithMock()
        {
            carLogic = new CarLogic(mockCarRepository.Object);

            Brand peugeot = new Brand() { Name = "Peugeot" };
            mockCarRepository.Setup(carRepo => carRepo.Create(It.IsAny<Car>()));

            mockCarRepository.Setup(carRepo => carRepo.GetAll()).Returns(
                   new List<Car>
                   {
                        new Car()
                        {
                            Brand=peugeot,
                            Model="306",
                            BasePrice=1000
                        },
                        new Car()
                        {
                            Brand = peugeot,
                            Model="406",
                            BasePrice=2000
                        }
                   }.AsQueryable()
                );
        }


        [TestCase(1)]
        [TestCase(10)]
        [TestCase(100)]
        public void TestCreateValid(int brandId)
        {
            Assert.That(
                () =>
                {
                    carLogic.Create(new Car() { Model = "xxx", BrandId = brandId });
                },
                Throws.Nothing
                );
        }
        [TestCase(-1)]
        [TestCase(-10)]
        [TestCase(-100)]
        public void TestCreateInValid(int brandId)
        {
            Assert.That(
                () =>
                {
                    carLogic.Create(new Car() { Model = "xxx", BrandId = brandId });
                },
                Throws.Exception
                );
        }

        [Test]
        public void TestAverage()
        {
            Brand peugeot = new Brand() { Name = "Peugeot", Id=1 };
            carLogic.Create(
                        new Car()
                        {
                            BrandId=1,
                            Brand = peugeot,
                            Model = "306",
                            BasePrice = 1000
                        }
            );
            carLogic.Create(
                        new Car()
                        {
                            BrandId=1,
                            Brand = peugeot,
                            Model = "406",
                            BasePrice = 2000
                        }
            );
            var res = carLogic.GetBrandAverages();
            Assert.That(res, Is.EquivalentTo(
                new List<AverageResult>
                {
                    new AverageResult()
                    {
                        BrandName="Peugeot",
                        AveragePrice=1500
                    }
                }
                ));
        }
    }
}
