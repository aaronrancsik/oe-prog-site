﻿using CarShop.Logic;
using CarShop.Models;
using CarShop.Repository;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CarShop.Tests
{
    [TestFixture]
    class TestWithFake
    {
        class FakeCarReposirory : ICarRepository
        {
            public void ChangePrice(int id, int newPrice)
            {
                throw new NotImplementedException();
            }

            public void Create(Car entity)
            {
            }

            public void Delete(Car entity)
            {
                throw new NotImplementedException();
            }

            public IQueryable<Car> GetAll()
            {
                Brand peugeot = new Brand() { Name = "Peugeot" };
                return new List<Car>
                {
                    new Car()
                    {
                        Brand=peugeot, 
                        Model="306",
                        BasePrice=1000 
                    },
                    new Car()
                    {
                        Brand = peugeot,
                        Model="406",
                        BasePrice=2000
                    }
                }.AsQueryable();
            }

            public Car GetOne(int id)
            {
                throw new NotImplementedException();
            }
        }


        [TestCase(1)]
        [TestCase(10)]
        [TestCase(100)]
        public void TestCreateValid(int brandId)
        {
            CarLogic carLogic = new CarLogic(new FakeCarReposirory());
            Assert.That(
                () =>
                {
                    carLogic.Create(new Car() { Model = "xxx", BrandId = brandId });
                },
                Throws.Nothing
                );
        }
        [TestCase(-1)]
        [TestCase(-10)]
        [TestCase(-100)]
        public void TestCreateInValid(int brandId)
        {
            CarLogic carLogic = new CarLogic(new FakeCarReposirory());
            Assert.That(
                () =>
                {
                    carLogic.Create(new Car() { Model = "xxx", BrandId = brandId });
                },
                Throws.Exception
                );
        }
    }


    
}
