﻿// See https://aka.ms/new-console-template for more information

using System;
using System.Diagnostics;
using System.Xml.Schema;

namespace ConsoleApp2
{
    class RSS
    {
        public string Title { get; set; }
        public string URL { get; set; }
    }

    class DataProcessor
    {
        public static string[] urls = {
            "http://hvg.hu/rss/rss.hvg/hirek",
            "https://sg.hu/plain/rss.xml",
            "https://www.hwsw.hu/xml/latest_news_rss.xml",
            "https://feeds.soundcloud.com/users/soundcloud:users:281745775/sounds.rss"
        };
        
        public static void Open(string url)
        {
            Process p = new Process();
            p.StartInfo = new ProcessStartInfo();
            p.StartInfo.FileName = "firefox"; // or Chrome or whatever, the .exe is maybe needed to place afterwards on Windows
            p.StartInfo.Arguments = url;
            p.Start();
            p.WaitForExit();
        }
    }
    
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}