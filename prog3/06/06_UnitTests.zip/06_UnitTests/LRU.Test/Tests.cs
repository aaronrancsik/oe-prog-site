﻿using Lru.Logic;
using NUnit.Framework;
using System;
using System.Collections.Generic;

namespace Lru.Test
{

    [TestFixture]
    public class Tests
    {
        [Test]
        public void TestCtorInitFields()
        {
            LRU storage = new LRU();
            Assert.That(storage.Recent, Is.Not.Null);
            Assert.That(storage.Recent, Is.Empty);
        }

        [Test]
        public void TestCtorDefaultParamater()
        {
            LRU storage = new LRU();
            Assert.That(storage.ListLimit, Is.EqualTo(LRU.DEFAULT_LIMIT));
        }

        [TestCase(1)]
        [TestCase(42)]
        [TestCase(512)]
        public void TestCtorParamaterSet(int limit)
        {
            LRU storage = new LRU(limit);
            Assert.That(storage.ListLimit, Is.EqualTo(limit));
        }

        // Boundry test
        // Fuzzing
        [TestCase(0)]
        [TestCase(-1)]
        public void TestCtorInvalidParamaterRefuse(int limit) // 2
        {
            Assert.That(
                () => { LRU store = new LRU(limit); },
                Throws.Exception.TypeOf<ArgumentOutOfRangeException>()
            );
        }

        LRU lru;
        const int LIMIT = 5;
        [SetUp]
        public void MySetup()
        {
            lru = new LRU(LIMIT);
        }

        [Test]
        public void TestAddNullShouldThrowException()
        {
            Assert.That(() =>
            {
                lru.Add(null);
            },
            Throws.ArgumentNullException);
        }


        [Test]
        public void TestIsLimitWorks() // 3 
        {
            object[] instances = new object[LIMIT*2];
            for (int i = 0; i < instances.Length; i++)
            {
                instances[i] = new { IDX = i};
                lru.Add(instances[i]);
            }
            Assert.That(lru.Recent.Count, Is.EqualTo(LIMIT));
            for (int i = 0; i < LIMIT; i++)
            {
                Assert.That(lru.Recent, Does.Contain(instances[i + LIMIT]));
            }
        }

        static IEnumerable<TestCaseData> CountSource
        {
            get
            {
                var first = new { IDX = 1 };
                var secound = new { IDX = 2 };
                var third = new { IDX = 3 };

                yield return new TestCaseData(new object[] { first, secound, third }, 3);
                yield return new TestCaseData(new object[] { first, first, third }, 2);
                yield return new TestCaseData(new object[] { first, first, first }, 1);
            }
        }

        [TestCaseSource(nameof(CountSource))]
        public void TestCount(object[] input, int expectedCount) // 5
        {
            foreach (var item in input)
            {
                lru.Add(item);
            }
            Assert.That(lru.Recent.Count, Is.EqualTo(expectedCount));
        }

        public static IEnumerable<TestCaseData> TestOrderSource
        {
            get
            {
                var first = new { IDX = 1 };
                var second = new { IDX = 2 };
                var third = new { IDX = 3 };
                List<TestCaseData> output = new List<TestCaseData>();
                output.Add(new TestCaseData
                (
                    new object[] { first, second, third }, // items added
                    new object[] { third, second, first } // expected order
                ));
                output.Add(new TestCaseData
                (
                    new object[] { first, second, second }, // items added
                    new object[] { second, first } // expected order
                ));
                output.Add(new TestCaseData
                (
                    new object[] { first, second, first }, // items added
                    new object[] { first, second } // expected order
                ));
                return output;
            }
        }

        [TestCaseSource(nameof(TestOrderSource))] // 6.
        public void TestOrder(object[] instancesToAdd, object[] expectedOrder)
        {
            foreach (object item in instancesToAdd) lru.Add(item);
            for (int i = 0; i < expectedOrder.Length; i++)
            {
                Assert.That(lru.Recent[i], Is.SameAs(expectedOrder[i]));
            }
            // A main-ben 6. modositas utan a 'TestIsLimitWorks' piros lett,
            // ezert szukseges volt egy 7. modotitas is.
            // Az ilyet regression-nek hivjuk, amikor egy modositas elront mar mukodo dolgokat.
        }


    }
}
