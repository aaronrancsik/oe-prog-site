﻿using NUnit.Framework;
using System;
using System.Collections.Generic;

namespace Stack
{
    public class MyStack
    {
        List<int> numbers = new List<int>();
        public void Push(int num)
        {
            numbers.Add(num);
        }
        public int Pop()
        {
            int num = numbers[numbers.Count - 1];
            numbers.RemoveAt(numbers.Count - 1);
            return num;
        }
    }

    // NUGET: Add nUnit, nUnit3TestAdapter, Microsoft.NET.Test.Sdk
    [TestFixture]
    public class StackTester
    {
        [Test]
        public void TrueIsTrue()
        {
            Assert.That(true, Is.True);
        }

        MyStack stack;
        [SetUp] // Minden test fuggveny futasa elott lefut
        public void MySetup()
        {
            stack = new MyStack();
        }

        [Test]
        public void TestAddAndPopShoudReturnTheSame()
        {
            stack.Push(42);
            Assert.That(stack.Pop(), Is.EqualTo(42));
        }

        [TestCase(new int[]{42,7,1,3}, new int[] {3,1,7,42 })]
        [TestCase(new int[]{100,500,-1,1}, new int[] {1,-1,500, 100})]
        public void TestOrder(int[] input, int[] outout)
        {
            foreach (var item in input)
            {
                stack.Push(item);
            }

            foreach (var o in outout)
            {
                Assert.That(stack.Pop(), Is.EqualTo(o));
            }
        } 

    }

}
