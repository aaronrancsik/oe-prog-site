﻿using System;
using System.Collections.Generic;

namespace Stack
{
    public class MyStack
    {
        List<int> numbers = new List<int>();
        public void Push(int num)
        {
            numbers.Add(num);
        }
        public int Pop()
        {
            int num = numbers[numbers.Count - 1];
            numbers.RemoveAt(numbers.Count - 1);
            return num;
        }
    }

    // NUGET: Add nUnit, nUnit3TestAdapter, Microsoft.NET.Test.Sdk
    public class StackTester
    {
    }

}
