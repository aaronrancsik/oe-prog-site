﻿using System;
using System.Collections.Generic;

namespace Lru.Logic
{
    public class LRU
    {
        public const int DEFAULT_LIMIT = 10;
        public List<object> Recent { get; private set; }
        public int ListLimit { get; private set; }
        public LRU(int limit = DEFAULT_LIMIT)
        {
            if (limit <= 0) // 2
            {
                throw new ArgumentOutOfRangeException(nameof(limit), "Must be positive"); 
            }
            Recent = new List<object>();
            ListLimit = limit;
            
        }
        public void Add(object subject) // SUT = System Under Test
        {
            if (subject == null) throw new ArgumentNullException(nameof(subject)); // 4
            if (Recent.Contains(subject)) Recent.Remove(subject); // 5
            // Recent.Add(subject); // 1 - Initial version
            Recent.Insert(0, subject); // 6
            // if (Recent.Count > ListLimit) Recent.RemoveAt(0); // 3
            if (Recent.Count > ListLimit) Recent.RemoveAt(Recent.Count-1); // 7

        }
    }
}
 