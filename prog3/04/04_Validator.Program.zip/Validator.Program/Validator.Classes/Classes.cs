﻿using System;
using System.Reflection;

namespace Validator.Classes
{
    [AttributeUsage(AttributeTargets.Property)]
    public class MaxLengthAttribute : Attribute
    {
        public int Length { get; private set; }
        public MaxLengthAttribute(int length)
        {
            Length = length;
        }
    }

    [AttributeUsage(AttributeTargets.Property)]
    public class RangeAttribute : Attribute
    {
        public int Max { get; private set; }
        public int Min { get; private set; }
        public RangeAttribute(int min, int max)
        {
            Max = max;
            Min = min;
        }
    }

    internal interface IValidation
    {
        bool Validate(object instance, PropertyInfo propertyInfo);
    }

    internal class MaxLengthValidation : IValidation
    {
        MaxLengthAttribute maxLength;

        public MaxLengthValidation(MaxLengthAttribute maxLength)
        {
            this.maxLength = maxLength;
        }

        public bool Validate(object instance, PropertyInfo propertyInfo)
        {
            if(propertyInfo.PropertyType == typeof(string))
            {
                var value = (string)propertyInfo.GetValue(instance);
                return value.Length <= maxLength.Length;
            }
            else
            {
                throw new InvalidOperationException();
            }
        }
    }

    internal class RangeValidation : IValidation
    {
        RangeAttribute range;
        public RangeValidation(RangeAttribute range)
        {
            this.range = range;
        }

        public bool Validate(object instance, PropertyInfo propertyInfo)
        {
            if (propertyInfo.PropertyType == typeof(int))
            {
                var value = (int)propertyInfo.GetValue(instance);
                return value >= range.Min && value <= range.Max;
            }
            else
            {
                throw new InvalidOperationException();
            }
        }
    }

    internal class ValidationFactory
    {
        public IValidation GetValidation(Attribute attribute)
        {
            if(attribute is MaxLengthAttribute)
            {
                return new MaxLengthValidation(attribute as MaxLengthAttribute);
            }
            else if (attribute is RangeAttribute)
            {
                return new RangeValidation(attribute as RangeAttribute);
            }
            else
            {
                return null;
            }
        }
    }

    public class ValidatorC
    {
        public bool Validate(object instance)
        {
            PropertyInfo[] properyInfos = instance.GetType().GetProperties();
            ValidationFactory validationFactory = new ValidationFactory();
            foreach(var propertyInfo in properyInfos)
            {
                var allAttributes = propertyInfo.GetCustomAttributes();
                foreach (var attribute in allAttributes)
                {
                    IValidation validation = validationFactory.GetValidation(attribute);
                    if(validation?.Validate(instance, propertyInfo) == false)
                    {
                        return false;
                    }
                }
            }
            return true;
        }
    }

}
