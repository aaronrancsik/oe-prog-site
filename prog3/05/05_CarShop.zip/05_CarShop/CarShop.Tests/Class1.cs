﻿using System;

namespace CarShop.Tests
{
    public class Class1
    {
    }
}
