﻿using CarShop.Models;
using CarShop.Repository;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace CarShop.Logic
{

    public class AverageResult
    {
        public string BrandName { get; set; }
        public double AveragePrice { get; set; }

        public override bool Equals(object obj)
        {
            if(obj is AverageResult)
            {
                var other = obj as AverageResult;
                return this.AveragePrice == other.AveragePrice && this.BrandName == other.BrandName; // close
            }
            else
            {
                return false;
            }
        }

        public override int GetHashCode()
        {
            return this.BrandName.GetHashCode() + (int)this.AveragePrice;
        }

        public override string ToString()
        {
            return $"BrandName={BrandName}, AveragePrice={AveragePrice}";
        }
    }

    public interface ICarLogic
    {
        Car GetOne(int id);
        IList<Car> GetAll();
        void ChangePrice(int id, int newPrice);
        IList<AverageResult> GetBrandAverages();
    }

    public class CarLogic : ICarLogic
    {
        ICarRepository carRepo;

        public CarLogic(ICarRepository carRepo)
        {
            this.carRepo = carRepo;
        }

        public void ChangePrice(int id, int newPrice)
        {
            carRepo.ChangePrice(id, newPrice);
        }

        public IList<Car> GetAll()
        {
            return carRepo.GetAll().ToList();
        }

        public IList<AverageResult> GetBrandAverages()
        {
            var q = from car in carRepo.GetAll()
                    group car by new { car.BrandId ,car.Brand.Name} into g
                    select new AverageResult() 
                    {
                        BrandName=g.Key.Name, 
                        AveragePrice = g.Average(x => x.BasePrice) ?? 0 
                    };
            return q.ToList();
        }

        public Car GetOne(int id)
        {
            return carRepo.GetOne(id);
        }
    }

}
