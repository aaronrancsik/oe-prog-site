﻿using CarShop.Data;
using CarShop.Logic;
using CarShop.Repository;
using System;
using System.Linq;

namespace CarShop.Program
{
    class Program
    {
        static void Main(string[] args)
        {
            CarDbContext ctx = new CarDbContext();
            Console.WriteLine(ctx.Cars.Count());
            Console.ReadLine();

            CarRepository carRepository = new CarRepository(ctx);
            CarLogic carLogic = new CarLogic(carRepository);

            var res = carLogic.GetBrandAverages();
            ;

        }
    }
}
