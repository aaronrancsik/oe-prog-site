﻿using CarShop.Models;
using System;
using System.Linq;

namespace CarShop.Repository
{
    public interface IRepository<T> where T : class
    {
        T GetOne(int id); //Read
        IQueryable<T> GetAll(); //Read
        // void Delete(int id / T entity);
        // void Creat(T entity);
        // !! NO !! Update
    }

    public interface ICarRepository: IRepository<Car>
    {
        //update
        void ChangePrice(int id, int newPrice);
    }
}
