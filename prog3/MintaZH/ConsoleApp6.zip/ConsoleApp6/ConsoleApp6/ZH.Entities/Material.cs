﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6.ZH.Entities
{
    [Table("Materials")]
    public class Material
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        
        [MaxLength(255)]
        [Required]
        public string Name { get; set; }

        [Required]
        public int QualityLevel { get; set; }
        
        [Required]
        public int Price { get; set; }

        [MaxLength(1024)]
        public string Note { get; set; }

        [Required]
        public bool FlagForDelete { get; set; }

        [NotMapped]
        public virtual ICollection<BuyableSet> BuyableSets { get; set; }
        public Material()
        {
            BuyableSets = new HashSet<BuyableSet>();
        }

    }
}
