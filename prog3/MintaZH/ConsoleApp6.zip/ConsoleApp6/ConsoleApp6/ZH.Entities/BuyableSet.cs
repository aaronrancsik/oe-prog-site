﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6.ZH.Entities
{
    [Table("BuyableSets")]
    public class BuyableSet
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        
        [Required]
        [ForeignKey(nameof(Mat))]
        public int MatId { get; set; }

        [Required]
        public int Quantity { get; set; }

        [Required]
        public bool Available { get; set; }
        
        [NotMapped]
        public virtual Material Mat { get; set; }
    }
}
