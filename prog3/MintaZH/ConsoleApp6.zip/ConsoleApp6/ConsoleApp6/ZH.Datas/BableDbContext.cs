﻿using ConsoleApp6.ZH.DataLoader;
using ConsoleApp6.ZH.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6.ZH.Datas
{
    public class BableDbContext:DbContext
    {
        public virtual DbSet<Material> Materials { get; set; }
        public virtual DbSet<BuyableSet> BuyableSets { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder
                    .UseLazyLoadingProxies()
                    .UseSqlServer(
                    @"Data Source=(LocalDB)\MSSQLLocalDB; AttachDbFilename=|DataDirectory|\BabelKftDB.mdf; Integrated Security=True; MultipleActiveResultSets=True");
            }
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<BuyableSet>(entity =>
            entity
            .HasOne(x => x.Mat)
            .WithMany(y => y.BuyableSets)
            .HasForeignKey(x => x.MatId)
            .OnDelete(DeleteBehavior.ClientSetNull)
            );

            Loader loader = new Loader("data.xml");
            modelBuilder.Entity<Material>().HasData(loader.LoadMaterials());
            modelBuilder.Entity<BuyableSet>().HasData(loader.LoadBuyables());
        }
        public BableDbContext()
        {
            Database.EnsureCreated();
        }
    }
}
