﻿using ConsoleApp6.ZH.Datas;
using System;
using System.Linq;

namespace ConsoleApp6
{
    class Program
    {
        static void Main(string[] args)
        {
            //Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\BabelKftDB.mdf;Integrated Security=True;MultipleActiveResultSets=True
            BableDbContext ctx = new BableDbContext();
            Console.WriteLine("A: "+ctx.Materials.Count());
            Console.WriteLine();

            var b = from mat in ctx.Materials
                    where mat.FlagForDelete
                    select mat.Name;
            Console.WriteLine("B: "+string.Join(", ",b));
            Console.WriteLine();

            var c = from buyable in ctx.BuyableSets
                    where buyable.Available && !buyable.Mat.FlagForDelete
                    orderby buyable.Quantity descending
                    select new { buyable.Id, buyable.MatId, buyable.Quantity, buyable.Available,buyable.Mat.FlagForDelete };
            Console.WriteLine("C: "+ string.Join("\n", c));
            Console.WriteLine();

            var d = from buyable in ctx.BuyableSets
                    group buyable by new { buyable.MatId, buyable.Mat.Name } into grp
                    select new {
                        Material = grp.Key.Name,
                        AvgBuyable = Math.Round(grp.Average(x => x.Quantity),2)
                    };
            Console.WriteLine("D: "+string.Join("\n", d));
            Console.WriteLine();

            var e = from mat in ctx.Materials
                    where mat.Name.Contains("beton")
                    select mat.Name;
            Console.WriteLine("E: "+string.Join(", ", e));


            Console.ReadLine();
        }

    }
}
