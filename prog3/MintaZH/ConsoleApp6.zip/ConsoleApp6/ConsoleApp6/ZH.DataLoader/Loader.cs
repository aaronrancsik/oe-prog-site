﻿using ConsoleApp6.ZH.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ConsoleApp6.ZH.DataLoader
{
    class Loader
    {
        XDocument doc;
        public Loader(string dataXml)
        {
            doc = XDocument.Load(dataXml);
        }
        public IEnumerable<Material> LoadMaterials()
        {
            List<Material> ret = new List<Material>();
            var materials = doc.Descendants("material");
            foreach (var item in materials)
            {
                int id = (int)item.Element("id");
                var name = item.Element("name").Value;
                int quality = (int)item.Element("quality");
                int price = (int)item.Element("price");
                var note = item.Element("note");
                bool deleted = item.Element("deleted").Value == "True" ? true : false;
                var m = new Material()
                { 
                    Id=id,
                    Name=name,
                    QualityLevel=quality,
                    Price=price,
                    FlagForDelete=deleted
                };

                if (note != null)
                    m.Note = note.Value;
                ret.Add(m);
            }
            return ret;
        }
        public IEnumerable<BuyableSet> LoadBuyables()
        {
            List<BuyableSet> ret = new List<BuyableSet>();
            var sets = doc.Descendants("buyable-set");
            foreach (var item in sets)
            {
                int id = (int)item.Element("id");
                int matId = (int)item.Element("mat_id");
                int quantity = (int)item.Element("quantity");
                bool available = item.Element("available").Value == "True" ? true : false;
                ret.Add(new BuyableSet()
                {
                    Id = id,
                    MatId = matId,
                    Quantity = quantity,
                    Available = available
                });
            }
            return ret;

        }
    }
}
