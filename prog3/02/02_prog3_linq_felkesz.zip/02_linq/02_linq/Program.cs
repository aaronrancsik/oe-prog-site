﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace _02_linq
{
    static class MyExtensions
    {
        public static void ToConsole<T>(this IEnumerable<T> input, string header)
        {
            Console.WriteLine($"*** {header} ***");
            foreach(var e in input)
            {
                Console.WriteLine(e);
            }
            Console.WriteLine($"*** {header} ***");
            Console.WriteLine();
        }
    }


    class Person
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string Dept { get; set; }
        public string Rank { get; set; }
        public string Phone { get; set; }
        public string Room { get; set; }

        public static Person Parse(XElement node)
        {
            return new Person()
            {
                Name = node.Element("name")?.Value,
                Email = node.Element("email")?.Value,
                Dept = node.Element("dept")?.Value,
                Rank = node.Element("rank")?.Value,
                Phone = node.Element("phone")?.Value,
                Room = node.Element("room")?.Value
            };
        }
    }

    class Program
    {

        static void Main(string[] args)
        {
            //Q1
            XDocument xDoc = XDocument.Load("people.xml");
            var q1 = xDoc.Descendants("person")
                .Where(x => !x.Element("room").Value.StartsWith("BA"))
                .Select(x => x.Element("name").Value);
            Console.WriteLine("Q0");
            foreach(var p in q1)
            {
                Console.WriteLine(p);
            }

            // Parse
            var people = xDoc.Descendants("person")
                .Select(x => Person.Parse(x));

            // Linq Object
            var parse = people.Where(x => !x.Room.StartsWith("BA"))
                .Select(x => new { x.Name, x.Email });
            Console.WriteLine("LINQ Object:");
            foreach(var p in parse)
            {
                Console.WriteLine($"{p.Name} - {p.Email}");
            }

            // All
            people.Select(x => x.Name).ToConsole("ALL WORKERS");

            int c = people.Select(a => a.Name).Count();


          


            Console.ReadLine();

        }
    }
}
