﻿using CarShop.Models;
using System;
using System.Linq;

namespace CarShop.Repository
{
    public interface IRepository<T> where T : class
    {
        T GetOne(int id); //Read
        IQueryable<T> GetAll(); //Read
        void Delete( T entity);
        void Delete(int id);
        void Create(T entity);
        void Update(T updated);
    }

    public interface ICarRepository: IRepository<Car>
    {
        //update
        void ChangePrice(int id, int newPrice);
    }

    public interface IBrandRepository: IRepository<Brand>
    {
        void ChangeBrandName(int id, string newBrandName);
    }
}
