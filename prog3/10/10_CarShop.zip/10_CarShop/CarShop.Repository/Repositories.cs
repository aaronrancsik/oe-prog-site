﻿using CarShop.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarShop.Repository
{
    public abstract class Repository<T> : IRepository<T> where T : class
    {
        protected DbContext ctx;
        public Repository(DbContext ctx)
        {
            this.ctx = ctx;
        }

        public void Create(T entity)
        {
            ctx.Set<T>().Add(entity);
            ctx.SaveChanges();
        }

        public void Delete(T entity)
        {
            ctx.Set<T>().Remove(entity);
            ctx.SaveChanges();
        }

        public abstract void Delete(int id);

        public IQueryable<T> GetAll()
        {
            return ctx.Set<T>();
        }
        public abstract T GetOne(int id);

        public abstract void Update(T updated);
    }

    public class CarRepository : Repository<Car>, ICarRepository
    {
        public CarRepository(DbContext ctx) : base(ctx) { }

        public void ChangePrice(int id, int newPrice)
        {
            var car = GetOne(id);
            if (car == null) throw new InvalidOperationException("Not found");
            car.BasePrice = newPrice;
            ctx.SaveChanges();

        }

        public override void Delete(int id)
        {
            Delete(GetOne(id));
        }

        public override Car GetOne(int id)
        {
            return GetAll().SingleOrDefault(x => x.Id == id);
        }

        public override void Update(Car updated)
        {
            var forUpdadte = GetOne(updated.Id);
            forUpdadte.BrandId = updated.BrandId;
            forUpdadte.BasePrice = updated.BasePrice;
            forUpdadte.Model = updated.Model;
            ctx.SaveChanges();
        }
    }

    public class BrandRepository : Repository<Brand>, IBrandRepository
    {
        public BrandRepository(DbContext ctx) : base(ctx)
        {
        }

        public void ChangeBrandName(int id, string newBrandName)
        {
            var result = GetOne(id);
            if (result == null)
                throw new InvalidOperationException("Not found");
        }

        public override void Delete(int id)
        {
            ctx.Set<Brand>().Remove(GetOne(id));
            ctx.SaveChanges();
        }

        public override Brand GetOne(int id)
        {
            return GetAll().SingleOrDefault(brand => brand.Id == id);
        }

        public override void Update(Brand updated)
        {
            var forUpdate = GetOne(updated.Id);
            forUpdate.Name = updated.Name;
            ctx.SaveChanges();
        }
    }
}


