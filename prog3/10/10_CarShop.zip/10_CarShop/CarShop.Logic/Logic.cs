﻿using CarShop.Models;
using CarShop.Repository;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace CarShop.Logic
{

   
    public interface ICarLogic
    {
        Car GetOne(int id);
        IList<Car> GetAll();
        void ChangePrice(int id, int newPrice);
        IList<AverageResult> GetBrandAverages();
        void Update(Car updated);
        void Create(Car newCar);
        void Delete(Car forDelete);
        void Delete(int id);
        double AveragePrice();
    }

    public class CarLogic : ICarLogic
    {
        ICarRepository carRepo;

        public void Delete(Car forDelete)
        {
            carRepo.Delete(forDelete);
        }
        public void Create(Car newCar)
        {
            if (newCar.BrandId < 1)
                throw new ArgumentException(nameof(newCar), "Brand id must be positive");
            carRepo.Create(newCar);
        }

        public CarLogic(ICarRepository carRepo)
        {
            this.carRepo = carRepo;
        }

        public void ChangePrice(int id, int newPrice)
        {
            carRepo.ChangePrice(id, newPrice);
        }

        public IList<Car> GetAll()
        {
            return carRepo.GetAll().ToList();
        }

        public IList<AverageResult> GetBrandAverages()
        {
            var q = from car in carRepo.GetAll()
                    group car by new { car.BrandId ,car.Brand.Name} into g
                    select new AverageResult() 
                    {
                        BrandName=g.Key.Name, 
                        AveragePrice = g.Average(x => x.BasePrice) ?? 0 
                    };
            return q.ToList();
        }

        public Car GetOne(int id)
        {
            return carRepo.GetOne(id);
        }

        public void Delete(int id)
        {
            carRepo.Delete(id);
        }

        public void Update(Car updated)
        {
            carRepo.Update(updated);
        }

        public double AveragePrice()
        {
            return (double)carRepo.GetAll().Average(x => x.BasePrice);
        }
    }

    public interface IBrandLogic
    {
        IList<Brand> GetAll();
        Brand GetOne(int id);
        void ChangeBrandName(int id, string newBrandName);
        void Create(Brand newBrand);
        void Delete(Brand forDelete);
        void Delete(int id);
        void Update(Brand value);
    }

    public class BrandLogic : IBrandLogic
    {
        IBrandRepository brandRepository;

        public BrandLogic(IBrandRepository brandRepository)
        {
            this.brandRepository = brandRepository;
        }

        public void ChangeBrandName(int id, string newBrandName)
        {
            brandRepository.ChangeBrandName(id, newBrandName);
        }

        public void Create(Brand newBrand)
        {
            brandRepository.Create(newBrand);
        }

        public void Delete(Brand forDelete)
        {
            brandRepository.Delete(forDelete);
        }

        public void Delete(int id)
        {
            brandRepository.Delete(id);
        }

        public IList<Brand> GetAll()
        {
            return brandRepository.GetAll().ToList();
        }

        public Brand GetOne(int id)
        {
            return brandRepository.GetOne(id);
        }

        public void Update(Brand value)
        {
            brandRepository.Update(value);
        }
    }
}
