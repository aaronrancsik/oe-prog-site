﻿using CarShop.Models;
using ConsoleTools;
using System;
using System.Linq;

namespace CarShop.Program
{
    class Program
    {
        static void Main(string[] args)
        {

            RestService restService = new RestService("http://localhost:50620");

            ConsoleMenu consoleMenu = new ConsoleMenu();
            consoleMenu.Add("List all brand", () => {
                var res = restService.Get<Brand>("/brand");
                foreach (var item in res)
                {
                    Console.WriteLine(new { id = item.Id, name=item.Name });
                }
                Console.ReadLine();
            });
            consoleMenu.Add("List all cars", () => {
                var res = restService.Get<Car>("/car");
                foreach (var item in res)
                {
                    Console.WriteLine(item.Model);
                }
                Console.ReadLine();
            });
            consoleMenu.Add("Add a brand", () => {
                var a = new Brand();
                restService.Post<Brand>(
                    new Brand() { 
                        Name = "Paugeot" 
                    },
                    "/brand"
                );
            });
            consoleMenu.Add("Average by brands", () => {
                var res = restService.Get<AverageResult>("/stat/averagebybrands");
                foreach (var item in res)
                {
                    Console.WriteLine(item);
                }
                Console.ReadLine();
            });
            consoleMenu.Add("Car average price", () => {
                var res = restService.GetSingle<double>("/stat/averageprice");
                Console.WriteLine($"Avg car price={res}");
                Console.ReadLine();
            });

            consoleMenu.Show();
        }
    }
}
