﻿using _03_code_first.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace _03_code_first
{
    static class Operations
    {
        public static void ToConsole<T>(this IEnumerable<T> input, string header)
        {
            Console.WriteLine($"************* {header} ************");
            foreach (var item in input) Console.WriteLine(item);
            Console.WriteLine($"************* {header} ************");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            CarDbContext DC = new CarDbContext();
            DC.Brands.Select(x => x.Name).ToConsole("Q2");

            DC.Cars.Select(x => new { x.Model, x.BasePrice, BrandName=x.Brand.Name })
                .ToConsole("Q3");

            var car_avg = from car in DC.Cars
                    group car by car.BrandId into g
                    select new { g.Key, AvgPrice = g.Average(x => x.BasePrice) };
            var q4_a = from car in DC.Cars
                    group car by new { car.BrandId ,car.Brand.Name} into g
                    select new { g.Key.Name, AvgPrice = g.Average(x => x.BasePrice) };
            q4_a.ToConsole("Q4 group by anon");

            var q4_b = from grp in car_avg
                     join brand in DC.Brands on grp.Key equals brand.Id
                     select new {brand.Name, AvgPrice = grp.AvgPrice};
            q4_b.ToConsole("Q4 join");

            var brand_cound = from car in DC.Cars
                              group car by car.BrandId into g
                              select new { BrandId = g.Key, Cnt = g.Count() };
            var q5 = from car in DC.Cars
                     join brandCount in brand_cound
                     on car.BrandId equals brandCount.BrandId
                     select new { car.Model, car.Brand.Name, brandCount.Cnt };
            q5.ToConsole("Q5");

            foreach (var car in DC.Cars.Where(x =>x.Brand.Name == "BMW"))
            {
                car.Model += "+";
            }
            DC.SaveChanges();

            var q6 = from car in DC.Cars
                     where car.Brand.Name == "BMW"
                     select car.Model;
            q6.ToConsole("Q6");

            foreach(var car in DC.Cars.Where(x => x.BasePrice < 20000))
            {
                Console.WriteLine(car.Model+" "+car.BasePrice); 
                car.BasePrice *= 3;
                Console.WriteLine(car.BasePrice);
            }
            DC.SaveChanges();


            var a3s = DC.Cars.Where(x => x.Model == "Audi A3").Select(x =>x);
            foreach(var a3 in a3s)
            {
                DC.Cars.Remove(a3);
            }
            DC.SaveChanges();

            Car newAudi = new Car()
            {
                Model = "A5",
                BasePrice = 555555,
                BrandId = 3
            };
            DC.Cars.Add(newAudi);
            DC.SaveChanges();

            DC.Cars
                .Where(x => x.Brand.Name == "Audi")
                .Select(x => x.Model)
                .ToConsole("Audi");
            
            Console.ReadLine();
        }
    }
}
