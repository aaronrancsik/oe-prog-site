﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace _02_linq
{
    static class MyExtensions
    {
        public static void ToConsole<T>(this IEnumerable<T> input, string header)
        {
            Console.WriteLine($"*** {header} ***");
            foreach(var e in input)
            {
                Console.WriteLine(e);
            }
            Console.WriteLine($"*** {header} ***");
            Console.WriteLine();
        }
    }


    class Person
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string Dept { get; set; }
        public string Rank { get; set; }
        public string Phone { get; set; }
        public string Room { get; set; }

        public static Person Parse(XElement node)
        {
            return new Person()
            {
                Name = node.Element("name")?.Value,
                Email = node.Element("email")?.Value,
                Dept = node.Element("dept")?.Value,
                Rank = node.Element("rank")?.Value,
                Phone = node.Element("phone")?.Value,
                Room = node.Element("room")?.Value
            };
        }
    }

    class Program
    {

        static void Main(string[] args)
        {
            //Q1
            XDocument xDoc = XDocument.Load("people.xml");
            var q1 = xDoc.Descendants("person")
                .Where(x => !x.Element("room").Value.StartsWith("BA"))
                .Select(x => x.Element("name").Value);
            Console.WriteLine("Q0");
            foreach(var p in q1)
            {
                Console.WriteLine(p);
            }

            // Parse
            var people = xDoc.Descendants("person")
                .Select(x => Person.Parse(x));

            // Linq Object
            var parse = people.Where(x => !x.Room.StartsWith("BA"))
                .Select(x => new { x.Name, x.Email });
            Console.WriteLine("LINQ Object:");
            foreach(var p in parse)
            {
                Console.WriteLine($"{p.Name} - {p.Email}");
            }

            // All
            people.Select(x => x.Name).ToConsole("ALL WORKERS");

            // Q2
            string dept = "Alkalmazott Informatikai Intézet";
            int num = people.Count(x => x.Dept == dept);
            int current = 0;
            int pagesize = 10;
            while (current < num)
            {
                var q2 = people
                    .Where(x => x.Dept == dept)
                    .Skip(current)
                    .Take(pagesize)
                    .Select(person => person.Name);
                q2.ToConsole($"Q2 #{current / pagesize + 1}");
                current += pagesize;
            }

            // Q3
            var q3 = from person in people
                     let minlen = people.Min(x => x.Name.Length)
                     let maxlen = people.Max(x => x.Name.Length)
                     where person.Name.Length == minlen ||
                     person.Name.Length == maxlen
                     select new { person.Name, person.Name.Length };
            q3.ToConsole("Q3");

           // Q4
           var q4 = from person in people
                    group person by person.Dept into g
                    select new { Dept = g.Key, Cnt = g.Count() };
            q4.ToConsole("Q4");

            // Q5
            var oneDept = q4.OrderByDescending(rec => rec.Cnt).FirstOrDefault();
            var oneDept_alter = q4.Aggregate((i, j) => i.Cnt > j.Cnt ? i : j);
            Console.WriteLine(oneDept.ToString());
            Console.WriteLine(oneDept_alter.ToString());
            Console.ReadLine();
            Console.ReadLine();






            Console.ReadLine();

        }
    }
}
