﻿using _03_code_first.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace _03_code_first
{
    static class Operations
    {
        public static void ToConsole<T>(this IEnumerable<T> input, string header)
        {
            Console.WriteLine($"************* {header} ************");
            foreach (var item in input) Console.WriteLine(item);
            Console.WriteLine($"************* {header} ************");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            CarDbContext DC = new CarDbContext();
            DC.Brands.Select(x => x.Name).ToConsole("Q1");

            Console.ReadLine();
        }
    }
}
