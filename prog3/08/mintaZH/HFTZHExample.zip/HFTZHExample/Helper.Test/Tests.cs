﻿using HFTZHExampleConsole.Helpers;
using HFTZHExampleConsole.Models;
using NUnit.Framework;
using System;

namespace Helper.Test
{

    [TestFixture]
    public class Tests
    {
        [Test]
        public void TestAttributeHelperValid()
        {
            var result = AttributeHelper.GetPropertyDisplayName<Product>(nameof(Product.Name));
            Assert.That(result, Is.EqualTo("Termek neve"));
        }

        class TestStudentClass
        {
            public string Neptun { get; set; }
        }
        [Test]
        public void TestAttributeHelperInValid()
        {
            var result = AttributeHelper.GetPropertyDisplayName<TestStudentClass>(nameof(TestStudentClass.Neptun));
            Assert.That(result, Is.EqualTo(nameof(TestStudentClass.Neptun)));
        }

        [Test]
        public void TestAttribueHelperNull()
        {
            Assert.That(
                () => { AttributeHelper.GetPropertyDisplayName<Product>(null); },
                Throws.TypeOf<ArgumentNullException>()
            );
        }
    }
}
