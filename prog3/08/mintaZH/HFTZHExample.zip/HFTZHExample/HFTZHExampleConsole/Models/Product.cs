﻿using HFTZHExampleConsole.Atributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HFTZHExampleConsole.Models
{
    public class Product
    {
        [DisplayName("Termek neve")]
        public string Name { get; set; }

        [DisplayName("Termek mennyisege")]
        public int Amount { get; set; }
    }
}
