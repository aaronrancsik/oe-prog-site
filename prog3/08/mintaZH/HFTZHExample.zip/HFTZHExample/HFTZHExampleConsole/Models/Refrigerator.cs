﻿using HFTZHExampleConsole.Atributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace HFTZHExampleConsole.Models
{
    public class Refrigerator
    {
        [DisplayName("Huto markaja")]
        public string Brand { get; set; }

        [DisplayName("Huto merete")]
        public int Capacity { get; set; }

        [DisplayName("Huto termekei")]
        public List<Product> Products { get; set; }
        public static Refrigerator FromXML(string name)
        {
            XDocument doc = XDocument.Load(name);
            var frigi = new Refrigerator();

            // doc.Element("refrigerator").Attribute
            frigi.Brand = doc.Root.Attribute("brand").Value;
            //frigi.Capacity = int.Parse(doc.Root.Attribute("capacity").Value);
            frigi.Capacity = (int)doc.Root.Attribute("capacity");

            frigi.Products = doc
                .Descendants("product")
                .Select(
                    x => new Product()
                    {
                        Name = x.Value,
                        Amount = (int)x.Attribute("amount")
                    }
                )
                .ToList();

            ;
            return frigi;

        }
    }
}
