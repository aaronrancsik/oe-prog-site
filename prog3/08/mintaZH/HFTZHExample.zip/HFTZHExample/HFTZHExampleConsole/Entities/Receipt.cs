﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HFTZHExampleConsole.Entities
{
    [Table("Receipts")]
    public class Receipt
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [MaxLength(50)]
        [Required]
        public string Name { get; set; }
        public int Price { get; set; }
        public bool IsSeductive { get; set; }
        
        [NotMapped]
        public virtual ICollection<Ingredient> Ingredients {get; set;}
        public Receipt()
        {
            Ingredients = new HashSet<Ingredient>();
        }
    }
}
