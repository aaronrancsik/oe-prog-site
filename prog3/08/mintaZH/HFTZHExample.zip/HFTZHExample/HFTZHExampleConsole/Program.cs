﻿using HFTZHExampleConsole.Data;
using HFTZHExampleConsole.Helpers;
using HFTZHExampleConsole.Models;
using System;
using System.Linq;

namespace HFTZHExampleConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            FoodDbContext ctx = new FoodDbContext();
            ///A
            Console.WriteLine("A: Recept db: "+ctx.Receipts.Count());
            
            //B
            var b1 = from recept in ctx.Receipts
                     where recept.IsSeductive
                     select recept.Name;
            Console.WriteLine("B1: "+ String.Join(", ", b1));

            var b2 = ctx.Receipts.Where(x => x.IsSeductive).Select(x => x.Name);
            Console.WriteLine("B2: "+ String.Join(", ", b2));

            //C
            var c = from recept in ctx.Receipts
                    where recept.Ingredients.Any(x => x.Name == "Olaj")
                    orderby recept.Price descending
                    select recept.Name;
            Console.WriteLine("C: "+ String.Join(", ", c));

            //D
            var d = from ingredient in ctx.Ingredients
                    group ingredient by ingredient.Name into grp
                    select new
                    {
                        Ingredient = grp.Key,
                        Sum = grp.Sum(x => x.Amount)
                    };
            Console.WriteLine("D:");
            foreach (var item in d.OrderBy(x=>x.Sum))
            {
                Console.WriteLine(item);
            }

            //E
            var frigi = Refrigerator.FromXML("frigo.xml");
            Console.WriteLine("E:");
            foreach (var item in frigi.Products)
            {
                Console.WriteLine(
                    "{2}:{0} {3}:{1}",
                    item.Name,
                    item.Amount,
                    AttributeHelper.GetPropertyDisplayName<Product>(nameof(Product.Name)),
                    AttributeHelper.GetPropertyDisplayName<Product>(nameof(Product.Amount))
                );
            }



            Console.ReadLine();
            //
        }
    }
}
