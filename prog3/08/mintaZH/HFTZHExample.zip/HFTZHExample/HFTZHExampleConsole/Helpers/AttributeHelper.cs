﻿using HFTZHExampleConsole.Atributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HFTZHExampleConsole.Helpers
{
    public static class AttributeHelper
    {
        public static string GetPropertyDisplayName<T>(string propertyName)
        {
            if (propertyName == null)
            {
                throw new ArgumentNullException(nameof(propertyName));
            }
            var info = typeof(T).GetProperty(propertyName);
            var attr = (DisplayNameAttribute)info.GetCustomAttributes(typeof(DisplayNameAttribute), false).SingleOrDefault();

            return attr?.Name ?? propertyName;
        }
    }
}
