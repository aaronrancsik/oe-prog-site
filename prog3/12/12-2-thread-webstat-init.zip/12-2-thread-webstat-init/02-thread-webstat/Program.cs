﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Text.Json;
using System.Threading;
using System.Xml.Linq;

namespace _02_thread_webstat
{
    class Measurement
    {
        public string Url { get; set; }
        public int Byte { get; set; }
        public int MilliSec { get; set; }
        public double Speed { get { return Math.Round((double)Byte / MilliSec, 3); } }

    }

    class Program
    {
        static void Main(string[] args)
        {
            Measurement[] measurements = new Measurement[] {
                new Measurement() { Url = "http://microsoft.com" },
                new Measurement() { Url = "http://bing.com" },
                new Measurement() { Url = "http://google.com" },
                new Measurement() { Url = "http://uni-obuda.hu" },
                new Measurement() { Url = "http://users.nik.uni-obuda.hu/siposm/" },
                new Measurement() { Url = "http://users.nik.uni-obuda.hu/prog3/" },
                new Measurement() { Url = "http://users.nik.uni-obuda.hu/gitstats/" },
                new Measurement() { Url = "http://users.nik.uni-obuda.hu/sztf2/" },
            };

            // info 

            // sync

            // returned info

            // openFileAsProcess

            // createXML lambda and call

            // createJSON lambda and call
        }

        // static void Measure(object o)

        // static void WriteOutName(string input)

        // static void WriteOutMeasurement(string url, double speed)
    }
}
