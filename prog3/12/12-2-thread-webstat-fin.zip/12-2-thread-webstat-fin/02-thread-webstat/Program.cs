﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Text.Json;
using System.Threading;
using System.Xml.Linq;

namespace _02_thread_webstat
{
    class Measurement
    {
        public string Url { get; set; }
        public int Byte { get; set; }
        public int MilliSec { get; set; }
        public double Speed { get { return Math.Round((double)Byte / MilliSec, 3); } }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Measurement[] measurements = new Measurement[] {
                new Measurement() { Url = "http://microsoft.com" },
                new Measurement() { Url = "http://bing.com" },
                new Measurement() { Url = "http://google.com" },
                new Measurement() { Url = "http://uni-obuda.hu" },
                new Measurement() { Url = "http://users.nik.uni-obuda.hu/siposm/" },
                new Measurement() { Url = "http://users.nik.uni-obuda.hu/prog3/" },
                new Measurement() { Url = "http://users.nik.uni-obuda.hu/gitstats/" },
                new Measurement() { Url = "http://users.nik.uni-obuda.hu/sztf2/" },
            };

            Thread[] threads = new Thread[measurements.Length];
            for (int i = 0; i < threads.Length; i++)
            {
                threads[i] = new Thread(Measure);
                threads[i].Name = measurements[i].Url.Replace("http://", "");
                threads[i].Start(measurements[i]);
            }

            // info
            for (int i = 0; i < threads.Length; i++)
            {
                WriteOutName(threads[i].Name);
            }

            // sync
            for (int i = 0; i < threads.Length; i++)
                threads[i].Join();

            // returned info
            foreach(var item in measurements.OrderByDescending(x =>x.Speed))
                WriteOutMeasurement(item.Url, item.Speed);

            // openFileAsProcess
            Action<string, string> openFileAsProcess = (filename, argument) =>
             {
                 Process p = new Process()
                 {
                     StartInfo = new ProcessStartInfo()
                     {
                         FileName = filename,
                         Arguments = argument
                     }
                 };
                 p.Start();
             };

            Action<Measurement[]> createXML = x =>
            {
                XDocument doc = new XDocument();
                doc.Add(new XElement("measurements"));
                for (int i = 0; i < x.Length; i++)
                {
                    doc.Root.Add(new XElement("measurement",
                        new XElement("URL", x[i].Url),
                        new XElement("Byte", x[i].Byte),
                        new XElement("MiliSec", x[i].MilliSec),
                        new XElement("Speed", x[i].Speed)
                        ));
                }
                string filename = "output.xml";
                doc.Save(filename);
                openFileAsProcess(@"C:\Program Files\Notepad++\notepad++.exe", filename);
            };
            createXML(measurements);

            Action<Measurement[]> createJSON = x =>
            {
                var json = JsonSerializer.Serialize(x);
                string filename = "output.json";
                File.WriteAllText(filename, json);
                openFileAsProcess(@"C:\Program Files\Notepad++\notepad++.exe", filename);
            };
            createJSON(measurements.OrderBy(x =>x.Speed).Select(x =>x).ToArray());

            Console.ReadLine();
        }

        static void Measure(object o)
        {
            Measurement measurement = o as Measurement;
            int iteration = 10;
            int SumByte = 0;
            int SumMiliSec = 0;
            Stopwatch stopwatch = new Stopwatch();
            for (int i = 0; i < iteration; i++)
            {
                stopwatch.Start();
                SumByte += new WebClient()?.DownloadString(measurement.Url).Length ?? 0;
                stopwatch.Stop();
                SumMiliSec += (int)stopwatch.ElapsedMilliseconds;
                Thread.Sleep(500); // DOS
            }
            measurement.Byte = (int)Math.Round((SumByte / (double)iteration),0);
            measurement.MilliSec = SumMiliSec / iteration;

        }

        static void WriteOutName(string input)
        {
            Console.Write("Waiting... ");
            Console.Write(input);
            Console.WriteLine(" to test..");
        }

        static void WriteOutMeasurement(string url, double speed)
        {
            Console.WriteLine("Measurement:");
            Console.WriteLine($"URL: {url}");
            Console.WriteLine($"Speed: {speed} kB/s");
        }
    }
}
