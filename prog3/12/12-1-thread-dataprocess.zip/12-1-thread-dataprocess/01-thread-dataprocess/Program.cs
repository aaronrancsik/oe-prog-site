﻿using System;
using System.IO;
using System.Threading;

namespace _01_thread_dataprocess
{
    class DataTransfer
    {
        public string OpenFile { get; set; }
        public string SaveAs { get; set; }
        public int TimeDelay { get; set; }
    }

    class DataProcessor
    {
        public static void Process(object o)
        {
            DataTransfer dt = o as DataTransfer;
            Console.WriteLine("Process.. "+dt.OpenFile);

            string full = File.ReadAllText(dt.OpenFile);

            string saveStr = "";
            foreach (var item in full.Split('\n'))
                if (item.Contains("DATE:"))
                    saveStr += item + "\n";

            Thread.Sleep(dt.TimeDelay * 1000);

            File.WriteAllText(dt.SaveAs, saveStr);
        }

        public static void CollectData(string[] outputs)
        {
            string full = "";
            for (int i = 0; i < outputs.Length; i++)
            {
                full += File.ReadAllText(outputs[i]);
                full += "\n";
            }

            File.WriteAllText("./_output/final.txt", full);
        }
    }



    class Program
    {
        static void Main(string[] args)
        {
            #region INIT

            string[] inputs = new string[] {
                    "./_files/file1.txt",
                    "./_files/file2.txt",
                    "./_files/file3.txt",
                    "./_files/file4.txt"
                };

            string[] outputs = new string[] {
                    "./_output/save_file1.txt",
                    "./_output/save_file2.txt",
                    "./_output/save_file3.txt",
                    "./_output/save_file4.txt"
                };

            int[] delays = new int[] { // * 1000 ==> msp
                    1,
                    1,
                    1,
                    4
                };

            #endregion


            Thread[] threads = new Thread[inputs.Length];

            for (int i = 0; i < threads.Length; i++)
            {
                threads[i] = new Thread(DataProcessor.Process);
                threads[i].Start(new DataTransfer()
                {
                    OpenFile = inputs[i],
                    SaveAs = outputs[i],
                    TimeDelay = delays[i]
                });
            }

            for (int i = 0; i < threads.Length; i++)
                threads[i].Join();

            DataProcessor.CollectData(outputs);
        }
    }
}
