﻿using CarShop.Data;
using CarShop.Models;
using CarShop.Repository;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CarShop.Program
{
    static class Operations
    {
        public static void ToConsole<T>(this IEnumerable<T> input, string header)
        {
            Console.WriteLine($"************* {header} ************");
            foreach (var item in input) Console.WriteLine(item);
            Console.WriteLine($"************* {header} ************");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            CarDbContext ctx = new CarDbContext();
            CarRepository carRepository = new CarRepository(ctx);
            BrandRepository brandRepository = new BrandRepository(ctx);


            //use REPO layer from main..
            brandRepository.Create(new Brand() { Name = "Opel" });
            int opelId = brandRepository.GetAll().SingleOrDefault(x => x.Name == "Opel").Id;  
            carRepository.Create(new Car() { Model = "Opel astra", BasePrice = 500, BrandId = opelId }); ; ;


            // use MODEL layer from main
            ctx.Cars.Select(x => x.Model).ToConsole("q1"); ; ;
            // ctx.Set<Car>();


            // In FF the main only use the logic's methods....
            Console.ReadLine();
        }
    }
}
