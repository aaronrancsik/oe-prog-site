﻿using CarShop.Models;
using System;
using System.Linq;

namespace CarShop.Repository
{
    public interface IRepository<T> where T : class
    {
        T GetOne(int id);
        IQueryable<T> GetAll();

        // NO update

        void Create(T newEntity);
        void Delete(T forDelete);
    }

    public interface ICarRepository : IRepository<Car>
    {
        void ChangePrice(int id, int newPrice);
        // void ChangeModel(int id, int newModel);
    }

    public interface IBrandRepository: IRepository<Brand>
    {
        void ChangeName(int id, string newName);
    }

}
