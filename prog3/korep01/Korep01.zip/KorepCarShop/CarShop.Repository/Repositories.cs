﻿using CarShop.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarShop.Repository
{
    public abstract class Repository<T> : IRepository<T> where T : class
    {
        protected DbContext context;
        protected Repository(DbContext context)
        {
            this.context = context;
        }

        public void Create(T newEntity)
        {
            context.Set<T>().Add(newEntity);
            context.SaveChanges();
        }

        public void Delete(T forDelete)
        {
            context.Set<T>().Remove(forDelete);
            context.SaveChanges();
        }

        public IQueryable<T> GetAll()
        {
            // Set = matematikai halmaz
            return context.Set<T>();
        }

        public abstract T GetOne(int id);
    }

    public class CarRepository : Repository<Car>, ICarRepository
    {
        public CarRepository(DbContext context) : base(context)
        {
        }

        public void ChangePrice(int id, int newPrice)
        {
            var car = GetAll().SingleOrDefault(x => x.CarId == id);
            if (car == null) throw new InvalidOperationException("Not found");
            car.BasePrice = newPrice;
            context.SaveChanges();

        }

        public override Car GetOne(int id)
        {
            return GetAll().SingleOrDefault(x => x.CarId == id);
        }
    }

    public class BrandRepository : Repository<Brand>, IBrandRepository
    {
        public BrandRepository(DbContext context) : base(context)
        {
        }

        public void ChangeName(int id, string newName)
        {
            var brand = GetAll().SingleOrDefault(x => x.Id == id);
            if (brand == null) throw new InvalidOperationException("Not found");
            brand.Name = newName;
            context.SaveChanges();
        }

        public override Brand GetOne(int id)
        {
            return GetAll().SingleOrDefault(x => x.Id == id);
        }
    }
}
